## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>")

## ----github, eval=FALSE-------------------------------------------------------
# install.packages("devtools")
# devtools::install_github("mongi126/Sphinx")

## ----tarball, eval=FALSE------------------------------------------------------
# install.packages("Sphinx_1.0.1.tar.gz", repos = NULL, type = "source")

## ----check, eval=FALSE--------------------------------------------------------
# library(Sphinx)
# packageVersion("Sphinx")
# help(package = "Sphinx")

