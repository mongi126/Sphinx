## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>", fig.align = "center")

## ----workflow-figure, echo=FALSE, out.width="100%", results='asis'------------
f <- "workflow.png"
f2 <- "../man/figures/workflow.png"
if (file.exists(f)) {
  knitr::include_graphics(f)
} else if (file.exists(f2)) {
  knitr::include_graphics(f2)
} else {
  cat("*Workflow diagram available on https://mongi126.github.io/Sphinx/*\n")
}

## ----install, eval=FALSE------------------------------------------------------
# # remotes::install_github("mongi126/Sphinx")
# # or: install.packages("Sphinx_1.0.1.tar.gz", repos = NULL, type = "source")
# library(Sphinx)
# packageVersion("Sphinx")

## ----quick-start, eval=FALSE--------------------------------------------------
# library(Sphinx)
# library(data.table)
# 
# df <- prepare_data(meta, cell_id_col = "Cell_ID", celltype_col = "celltype")
# 
# dist_result <- calculate_celltype_distances(df)
# edges <- build_spatial_network(df, method = "auto")
# feat <- calculate_neighborhood_features(df, edges)
# clus <- cluster_neighborhoods(feat, edges, method = "kmeans", k = 10)
# 
# visualize_spatial_distribution(df, point_size = 0.45)
# visualize_distance_heatmap(dist_result, show_values = TRUE)
# visualize_spatial_network(
#   clus, edges, edge_mode = "top", top_n = 1500, point_alpha = 1
# )

