## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>", fig.align = "center", out.width = "92%")

## ----prep, eval=FALSE---------------------------------------------------------
# library(Sphinx)
# library(data.table)
# library(dplyr)
# library(ggplot2)
# 
# # meta: Cell_ID, X, Y, celltype
# df <- prepare_data(
#   meta, cell_id_col = "Cell_ID", x_col = "X", y_col = "Y",
#   celltype_col = "celltype"
# )

## ----spat, eval=FALSE---------------------------------------------------------
# visualize_spatial_distribution(
#   df, point_size = 0.45, point_alpha = 0.95,
#   title = "Annotated cell types"
# )

## ----spat-fig, echo=FALSE, results='asis'-------------------------------------
f <- "01_spatial_distribution_celltype.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----dist, eval=FALSE---------------------------------------------------------
# dist_result <- calculate_celltype_distances(df, celltype_col = "celltype")
# visualize_distance_heatmap(dist_result, show_values = TRUE)
# visualize_distance_parallel(dist_result)

## ----dist-fig, echo=FALSE, results='asis'-------------------------------------
f <- "02_distance_heatmap.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----net, eval=FALSE----------------------------------------------------------
# edges <- build_spatial_network(df, method = "auto", celltype_col = "celltype")
# feat <- calculate_neighborhood_features(df, edges, celltype_col = "celltype")
# clus <- cluster_neighborhoods(feat, edges, method = "kmeans", k = 10)

## ----cn, eval=FALSE-----------------------------------------------------------
# visualize_spatial_distribution(
#   clus, celltype_col = "Neighborhood_Cluster",
#   point_size = 0.45, title = "Neighborhood clusters"
# )
# 
# comp <- calculate_cluster_composition(clus)
# plot_composition_barplot(comp)
# plot_composition_heatmap(comp, cell_fontsize = 10)

## ----cn-fig, echo=FALSE, results='asis'---------------------------------------
f <- "05_spatial_distribution_clusters.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----bar-fig, echo=FALSE, results='asis'--------------------------------------
f <- "07_cluster_composition_barplot.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----heat-comp-fig, echo=FALSE, results='asis'--------------------------------
f <- "06_composition_heatmap.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----purity, eval=FALSE-------------------------------------------------------
# pur <- calculate_neighborhood_purity(clus, method = "knn", n_neighbors = 10)
# visualize_neighborhood_purity(pur, point_size = 0.55)

## ----purity-fig, echo=FALSE, results='asis'-----------------------------------
f <- "04_neighborhood_purity.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----intx, eval=FALSE---------------------------------------------------------
# intx <- analyze_spatial_interactions(clus, edges, celltype_col = "celltype")
# 
# visualize_interaction_heatmap(
#   intx$interaction_matrix, transform = TRUE,
#   display_numbers = FALSE, cellwidth = 10, cellheight = 10
# )
# 
# visualize_interaction_network(intx$network)

## ----intx-hm, echo=FALSE, results='asis'--------------------------------------
f <- "08_interaction_heatmap.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----intx-net, echo=FALSE, results='asis'-------------------------------------
f <- "11_cell_interaction_network.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----spatnet, eval=FALSE------------------------------------------------------
# visualize_spatial_network(
#   clus, edges, edge_mode = "top", top_n = 1200,
#   point_size = 0.5, point_alpha = 1
# )
# 
# cx <- mean(range(clus$X)); cy <- mean(range(clus$Y))
# zr <- max(diff(range(clus$X)), diff(range(clus$Y))) * 0.07
# visualize_spatial_network(
#   clus, edges,
#   edge_mode = "random", max_edges = 180,
#   zoom_center = c(cx, cy), zoom_radius = zr,
#   point_size = 2.2, point_alpha = 1,
#   title = "Spatial network (local zoom)"
# )

## ----spatnet-fig, echo=FALSE, results='asis'----------------------------------
f <- "10_spatial_network.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----spatnet-zoom, echo=FALSE, results='asis'---------------------------------
f <- "10_spatial_network_zoom.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----vor, eval=FALSE----------------------------------------------------------
# visualize_voronoi(clus, coloring = "neighborhood")

## ----vor-fig, echo=FALSE, results='asis'--------------------------------------
f <- "12_voronoi_neighborhood.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

