## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>", fig.align = "center", out.width = "90%")

## ----pkgs, eval=FALSE---------------------------------------------------------
# library(Sphinx)
# library(Seurat)
# library(dplyr)
# library(ggplot2)

## ----load, eval=FALSE---------------------------------------------------------
# obj <- load_spatial_data(filename = "reg055_A_counts_with_coords.csv")
# # Or construct a Seurat object from an expression matrix plus X / Y metadata.

## ----filter, eval=FALSE-------------------------------------------------------
# obj_filtered <- filter_data(obj, nFeature_quantile_threshold = 0.05)

## ----process, eval=FALSE------------------------------------------------------
# obj_processed <- process_data(obj_filtered, dims = 1:15, resolution = 0.5)

## ----elbow, eval=FALSE--------------------------------------------------------
# plot_elbow(obj_processed, save_path = "elbow_plot.png")

## ----elbow-fig, echo=FALSE, out.width="70%", results='asis'-------------------
f <- "elbow_plot.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----coords, eval=FALSE-------------------------------------------------------
# obj_processed <- extract_spatial_coordinates(obj_processed)

## ----viz, eval=FALSE----------------------------------------------------------
# plots <- visualize_results(obj_processed, save_dir = "preprocess_plots/")
# # plots$umap_plot, plots$spatial_plot

## ----umap-fig, echo=FALSE, out.width="80%", results='asis'--------------------
f <- "cluster_umap.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----spat-clus-fig, echo=FALSE, out.width="80%", results='asis'---------------
f <- "spatial_clusters.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----save, eval=FALSE---------------------------------------------------------
# saveRDS(obj_processed, "reg055_A_processed.rds")

