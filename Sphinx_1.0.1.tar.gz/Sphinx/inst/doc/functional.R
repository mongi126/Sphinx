## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>", fig.align = "center", out.width = "92%")

## ----prep, eval=FALSE---------------------------------------------------------
# library(Sphinx)
# library(dplyr)
# 
# protein_df <- prepare_protein_data(clus, expr_df)

## ----de, eval=FALSE-----------------------------------------------------------
# diff_res <- perform_differential_expression(
#   protein_df,
#   test_level = "spatial_block"
# )

## ----volcano, eval=FALSE------------------------------------------------------
# plot_volcano_all_clusters(
#   diff_res,
#   diff_thresh = 0.15,
#   p_thresh = 0.05,
#   y_cap = 50,
#   ncol = 3,
#   save_plot = TRUE,
#   output_dir = "functional_plots",
#   filename = "VolcanoPlots_AllClusters"
# )

## ----volcano-fig, echo=FALSE, results='asis'----------------------------------
f <- "VolcanoPlots_AllClusters.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----enrich, eval=FALSE-------------------------------------------------------
# enrich <- perform_cluster_enrichment(
#   diff_res,
#   species = "human",
#   pvalueCutoff = 0.05,
#   mean_diff_cutoff = 0
# )
# 
# plots <- plot_enrichment_results(
#   enrich,
#   top_n = 5,
#   fdr_cutoff = 0.05,
#   base_font_size = 12,
#   save_plot = TRUE,
#   output_dir = "enrichment_plots"
# )

## ----bar-fig, echo=FALSE, results='asis'--------------------------------------
f <- "bar_plot.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----bubble-fig, echo=FALSE, results='asis'-----------------------------------
f <- "bubble_plot.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

