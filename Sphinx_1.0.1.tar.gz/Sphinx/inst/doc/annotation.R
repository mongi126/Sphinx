## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>", fig.align = "center", out.width = "90%")

## ----load, eval=FALSE---------------------------------------------------------
# library(Sphinx)
# library(Seurat)
# library(ggplot2)
# 
# obj <- readRDS("reg055_A_processed.rds")

## ----markers, eval=FALSE------------------------------------------------------
# top5 <- find_top_markers(
#   obj,
#   assay = DefaultAssay(obj),
#   save_path = "top5proteins.csv"
# )

## ----marker-viz, eval=FALSE---------------------------------------------------
# plot_marker_violin(
#   obj,
#   markers = c("CD3", "CD20", "CD8", "CD4", "CD68", "Cytokeratin",
#               "CD31", "aSMA", "CD45", "FOXP3", "Vimentin", "Ki67"),
#   group_by = "seurat_clusters",
#   assay = DefaultAssay(obj),
#   save_path = "allmarker.png",
#   width = 12, height = 14
# )
# 
# plot_marker_heatmap(
#   obj, top_markers = top5, group_by = "seurat_clusters",
#   assay = DefaultAssay(obj), save_path = "marker_heatmap.png"
# )
# 
# plot_umap_markers(
#   obj, markers = head(top5$gene, 6),
#   output_file = "umap_markers_plot.png"
# )

## ----show-violin, echo=FALSE, out.width="90%", results='asis'-----------------
f <- "allmarker.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----show-heat, echo=FALSE, out.width="85%", results='asis'-------------------
f <- "marker_heatmap.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----show-umap-markers, echo=FALSE, out.width="85%", results='asis'-----------
f <- "umap_markers_plot.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----show-spatial-markers, echo=FALSE, out.width="85%", results='asis'--------
f <- "spatial_markers.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----annotate, eval=FALSE-----------------------------------------------------
# obj <- annotate_celltypes(
#   obj,
#   cluster_ids = c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"),
#   celltype_labels = c(
#     "CD4+ T cells", "CD8+ T cells", "CD68+CD163+ macrophages", "CD68+ macrophages",
#     "tumor cells", "B cells", "tumor cells", "CD68+ macrophages", "B cells",
#     "CD4+ T cells", "B cells", "B cells", "vasculature"
#   ),
#   cluster_column = "seurat_clusters"
# )
# 
# plot_annotated_umap(obj, save_path = "umap_by_celltype.png")
# plot_spatial_distribution(obj, save_path = "celltype_spatial_plot.png", point.size = 0.4)

## ----show-ann-umap, echo=FALSE, out.width="85%", results='asis'---------------
f <- "umap_by_celltype.png"
if (file.exists(f)) knitr::include_graphics(f) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----show-spatial, echo=FALSE, out.width="85%", results='asis'----------------
f1 <- "celltype_spatial_plot.png"
f2 <- "01_spatial_distribution_celltype.png"
if (file.exists(f1)) knitr::include_graphics(f1) else if (file.exists(f2))
  knitr::include_graphics(f2) else
  cat("*Figure available on https://mongi126.github.io/Sphinx/*\n")

## ----save, eval=FALSE---------------------------------------------------------
# saveRDS(obj, "reg055_A_annotated.rds")

